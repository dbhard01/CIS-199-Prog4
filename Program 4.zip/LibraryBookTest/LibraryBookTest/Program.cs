﻿// B1773
// Program 4
// Tuesday, December 5
// CIS 199-75-4178
// This assignment explores the creation of a reusable class and separate GUI application that creates a list objects.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace LibraryBookTest
{
    class Program
    {
        static void Main(string[] args)
        {
            LibraryBook book1 = new LibraryBook("Dare to Be Uncommon", "Tony Dungy", "Group Publishing", 2009, "123456"); // Listing Book1's Info 
            LibraryBook book2 = new LibraryBook("To Kill A Mockingbird","Harper Lee", "Warner Books Inc.", 1960, "789101"); // Listing Book2's Info
            LibraryBook book3 = new LibraryBook("The Outsiders", "S.E. Hinton", "Viking Press", 1967, "987654"); //Listing Book3's Info
            LibraryBook book4 = new LibraryBook("Harry Potter and The Sorcerer's Stone", "J.K. Rowling", "Bloomsbury", 1997, "456123"); // Listing Book4's Info
            LibraryBook book5 = new LibraryBook("The Great Gatsby", "F. Scott Fitzgerald", "Scribner", 1925, "321654"); // Listing Book5's Info
            //created five-element Employee array
            LibraryBook[] books = new LibraryBook[5];

            books[0] = book1;
            books[1] = book2;
            books[2] = book3;
            books[3] = book4;
            books[4] = book5;

            //Original book data before the books were checked out.
            WriteLine("\n");
            WriteLine("[BEFORE books were checked out and changed from original data]");
            WriteLine("\n");
            PrintOutData(books); // Print out of the books data.

            // The changed properties after the books were checked out.
            WriteLine("\n");
            WriteLine("[AFTER books were CHECKED OUT and changed from original data]");
            book3.CallNumber = "741852"; //changing book3 call number
            book4.Publisher = "Chronicle"; // changing book4 publisher
            book2.CheckOut(); //checking out book2
            book1.CopyrightYear = 2010; //changing book1 copyright year.
            book5.CheckOut(); //checking out book5.
            WriteLine("\n");
            PrintOutData(books); // Print out of the books data.


            book2.ReturnToShelf(); //returning book2
            book5.ReturnToShelf(); //returning book5
            WriteLine("\n");
            WriteLine("[AFTER books were RETURNED and changed back to original data]");
            WriteLine("\n");
            book1.CopyrightYear = 2009; //changing back book1 copyright year
            book3.CallNumber = "987654"; // changing back book3 call number.
            book4.Publisher = "Bloomsbury"; //changing back book4 publisher
            PrintOutData(books); // Print out of the books data.
        }
                //Precondition: No precondition
                //Postcondition:Method for printing out the books data.
                public static void PrintOutData(LibraryBook[] books)
                {
                    foreach(LibraryBook ListofBooks in books)
                    {
                      WriteLine(ListofBooks);
                    }           
                }
    }
}
