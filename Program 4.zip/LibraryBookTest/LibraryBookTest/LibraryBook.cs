﻿// B1773
// Program 4
// Tuesday, December 5
// CIS 199-75-4178
// This assignment explores the creation of a reusable class and separate GUI application that creates a list objects.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace LibraryBookTest
{
    public class LibraryBook
    {
        private string _bookTitle; // Book Title set as a string
        private string _author; // Book author set as a string
        private string _publisher; //Book publisher set as a string
        private int _copyrightYear; //Book copyright year set as 
        private string _callNumber; //Book call number set as a string 
        private bool _checkedOutStatus = false; //Book checkout status set as a bool 

        //Precondition: No neative numbers should be used. Each string variable needs to have words not numbers.
        //Postcondition: The LibraryBook object has been initialized with the specified Title, Author, Publisher, CopyrightYear, and CallNumber.
        public LibraryBook(string bt, string a, string p, int cy, string cn)
        {
            Title = bt; // set the title property
            Author = a; // set the author property
            Publisher = p; // set the publisher property
            CopyrightYear = cy; // set the copyright year property
            CallNumber = cn; // set the call number property

        }

        //Prcondition: No Precondition
        //Postcondition: _bookTitle is returned 
        public string Title
        {
            get
            {
                return _bookTitle;
            }

            set
            {
                _bookTitle = value;
            }

        }
        //Prcondition: No Precondition
        //Postcondition: _author is returned
        public string Author
        {
            get
            {
                return _author;
            }

            set
            {
                _author = value;
            }
        }
        //Prcondition: No Precondition
        //Postcondition: _publisher is returned 
        public string Publisher
        {
            get
            {
                return _publisher;
            }

            set
            {
                _publisher = value;
            }
        }
        //Prcondition: The copyright year cannot be negative
        //Postcondition: If copyright number is negative or has no number at all, then the default copyright year will be 2017.
        public int CopyrightYear
        {
            get
            {
                return _copyrightYear;
            }

            set
            {
                if (value >= 0)
                    _copyrightYear = value;
                else
                    _copyrightYear = 2017;
            }
        }
        //Prcondition: No Precondition
        //Postcondition: _callNumber is returned
        public string CallNumber
        {
            get
            {
                return _callNumber;
            }

            set
            {
                _callNumber = value;
            }
        }

       
        // Method that checks out a book
        public void CheckOut()
        {
            _checkedOutStatus = true;
        }
        // Method that returns a book back to the shelf
        public void ReturnToShelf()
        {
            _checkedOutStatus = false;
        }

        // Method that determines if a book is checked out or not
        public bool IsCheckedOut()
        {
            return _checkedOutStatus;
        }

        // Precondition: No precondition 
        //Postcondition: A string is returned concatenated to lay out the format when test program runs.
        public override string ToString()
        {
            return $"Book Title: {Title} {Environment.NewLine} + Book Author: {Author} {Environment.NewLine} + Publisher: {Publisher} {Environment.NewLine} + Copyright Year: {CopyrightYear} {Environment.NewLine} + Call Number: {CallNumber} {Environment.NewLine} + Is The Book Checked out? {IsCheckedOut()}";
        }


        
    }

}
